# Proyecto Web Electromiller

## 1. Descripción Técnica del Proyecto

Este proyecto es un **sitio web estático** diseñado para la tienda de muebles y electrodomésticos Electromiller, ubicada en Facatativá. El objetivo principal es ofrecer una presencia digital optimizada para el rendimiento y el SEO local.

El proyecto está construido con tecnologías web fundamentales (HTML5, CSS3, JavaScript puro) y sigue una arquitectura modular y *mobile-first*. Incluye un catálogo de productos dinámico que se carga desde un archivo JSON local y una página de contacto con un mapa interactivo implementado con la librería Leaflet.js.

## 2. Estructura Completa del Proyecto

La estructura de directorios se ha mantenido exactamente como se especificó en el archivo de origen, garantizando la integridad de las rutas relativas.

```
.
├── index.html
├── productos.html
├── nosotros.html
├── contacto.html
├── css/
│   ├── style.css
│   ├── responsive.css
│   └── animations.css
├── js/
│   ├── main.js
│   └── productos.js
├── images/
│   ├── heroes/
│   │   ├── hero-bg.jpg
│   │   └── store-front.jpg
│   ├── icons/
│   │   ├── icon-headset.svg
│   │   ├── icon-shield.svg
│   │   └── icon-truck.svg
│   ├── logo/
│   │   └── logo-electromiller.jpg
│   └── productos/
│       ├── comedor-6p.jpg
│       ├── estufa-indurama.jpg
│       ├── lavadora-lg.jpg
│       ├── lg-tv-55.jpg
│       ├── nevera-haceb.jpg
│       ├── producto-6660.jpg
│       ├── samsung-crystal.jpg
│       └── sofa-modular.jpg
├── data/
│   └── productos.json
└── docs/
    └── guia-integracion.txt
```

## 3. Explicación Técnica de Carpetas y Archivos

| Carpeta/Archivo | Descripción Técnica |
| :--- | :--- |
| `index.html` | **Página Principal (Landing Page).** Contiene la sección Hero, *Features*, productos destacados (cargados por `js/main.js`) y categorías. |
| `productos.html` | **Catálogo de Productos.** Incluye la interfaz de filtros (categoría, marca, precio) y la cuadrícula donde se renderizan los productos dinámicamente desde `data/productos.json` mediante `js/productos.js`. |
| `nosotros.html` | **Página Institucional.** Detalla la Misión, Visión, Historia y el Equipo de la empresa. |
| `contacto.html` | **Página de Contacto.** Contiene el formulario de contacto (simulado) y la integración del mapa interactivo con Leaflet.js. |
| `css/` | **Estilos en Cascada.** Contiene la lógica de diseño modular del sitio. |
| `css/style.css` | **Estilos Base.** Define variables CSS (`:root`), reset, tipografía, botones y el diseño principal de componentes (Header, Footer, Cards). |
| `css/responsive.css` | **Media Queries.** Contiene las reglas de diseño para tabletas y móviles, implementando el enfoque *mobile-first*. |
| `css/animations.css` | **Efectos Visuales.** Define las animaciones CSS (`@keyframes`) como `fadeInUp` y `scaleIn`, utilizadas para mejorar la experiencia de usuario. |
| `js/` | **Scripts de Funcionalidad.** Contiene la lógica interactiva del lado del cliente. |
| `js/main.js` | **Funcionalidad General.** Maneja el menú móvil, el *smooth scroll*, la simulación del formulario de contacto y la carga de productos destacados en `index.html`. |
| `js/productos.js` | **Lógica del Catálogo.** Se encarga de cargar `productos.json`, configurar los filtros y renderizar la lista completa de productos en `productos.html`. |
| `images/` | **Activos Visuales.** Organizado en subcarpetas para una mejor gestión de recursos. |
| `data/` | **Datos Estructurados.** Contiene la fuente de datos para el catálogo. |
| `data/productos.json` | **Base de Datos de Productos.** Archivo JSON que almacena la información estructurada de cada producto (ID, nombre, precio, imagen, etc.). |
| `docs/` | **Documentación Interna.** |
| `docs/guia-integracion.txt` | **Guía de Administración.** Instrucciones detalladas para la actualización de contenido, colores y productos. |

## 4. Flujo de Renderizado (HTML, CSS, JS)

El proyecto sigue un flujo de renderizado estándar para sitios estáticos:

1.  **HTML (Estructura):** El navegador carga el archivo HTML (ej. `index.html`), que define la estructura semántica del contenido y enlaza los recursos externos.
2.  **CSS (Estilo):** Se cargan los archivos CSS (`style.css`, `responsive.css`, `animations.css`). El uso de **variables CSS** en `style.css` permite una personalización centralizada de la paleta de colores.
3.  **JavaScript (Interactividad y Datos):**
    *   **`js/main.js`** se ejecuta en todas las páginas. Inicializa el menú móvil y el *scroll* suave. En `index.html`, llama a `loadFeaturedProducts()` para leer `data/productos.json` y renderizar los productos destacados.
    *   **`js/productos.js`** se ejecuta exclusivamente en `productos.html`. Carga el catálogo completo desde `data/productos.json`, configura los *event listeners* para los filtros y renderiza la lista de productos filtrados.
    *   **Leaflet.js** se carga en `contacto.html` para inicializar el mapa interactivo, utilizando coordenadas geográficas fijas para la ubicación de la tienda.

## 5. Requisitos y Dependencias Externas

El proyecto es ligero y tiene pocas dependencias externas, lo que facilita su mantenimiento y despliegue:

*   **Tipografía:** Google Fonts (Montserrat y Open Sans). Se cargan directamente desde la CDN en los archivos HTML.
*   **Mapa Interactivo:** [Leaflet.js](https://leafletjs.com/) (v1.7.1). Se utiliza para mostrar la ubicación de la tienda en `contacto.html`. Se carga tanto el archivo CSS (`leaflet.css`) como el script (`leaflet.js`) desde su CDN.

## 6. Indicaciones para Desplegar el Proyecto

Dado que es un proyecto puramente estático (HTML, CSS, JS, JSON), el despliegue es sencillo y no requiere configuración de servidor ni bases de datos.

### Despliegue en GitHub Pages

1.  Sube todo el contenido del proyecto (todas las carpetas y archivos) a un repositorio de GitHub.
2.  Ve a la configuración del repositorio (**Settings** > **Pages**).
3.  En la sección **Source**, selecciona la rama principal (`main` o `master`) y la carpeta raíz (`/`).
4.  Guarda los cambios. GitHub Pages desplegará automáticamente el sitio en la URL `https://<usuario>.github.io/<repositorio>/`.

### Despliegue en Netlify

1.  Conecta tu cuenta de Netlify con tu repositorio de GitHub.
2.  Crea un nuevo sitio a partir de Git.
3.  Selecciona el repositorio del proyecto.
4.  Asegúrate de que la configuración de construcción sea:
    *   **Build command:** (Dejar vacío, no es necesario)
    *   **Publish directory:** (Dejar vacío o `./`, ya que los archivos están en la raíz)
5.  Netlify desplegará el sitio automáticamente en un dominio temporal que puedes personalizar.

### Despliegue en Hostinger (u otro Hosting Tradicional)

1.  Accede al panel de control de tu hosting (cPanel o similar).
2.  Navega al administrador de archivos (`File Manager`).
3.  Sube todo el contenido del proyecto (carpetas `css`, `js`, `images`, `data`, `docs` y los archivos HTML) a la carpeta raíz de tu dominio (generalmente `public_html`).
4.  El sitio estará disponible inmediatamente en tu dominio.

## 7. Recomendaciones para Mantenimiento del Sitio

*   **Temas y Colores:** Utiliza las variables CSS definidas en `css/style.css` (`--color-primary`, `--color-accent`, etc.) para realizar cambios de marca rápidos y consistentes en todo el sitio.
*   **Imágenes:** Mantén las imágenes optimizadas para la web (compresión y dimensiones adecuadas) para asegurar la velocidad de carga.
*   **Consistencia de Rutas:** Si añades nuevas páginas, asegúrate de actualizar los enlaces de navegación en el `header` y `footer` de **todos** los archivos HTML.

## 8. Buenas Prácticas de Actualización del Contenido

Para la gestión del contenido, consulta la guía detallada en `docs/guia-integracion.txt`. Los puntos clave son:

*   **Actualización de Productos:** Modifica únicamente el archivo `data/productos.json`. No es necesario tocar el código HTML o JavaScript para añadir, eliminar o modificar productos.
*   **Imágenes de Productos:** Coloca las nuevas imágenes en `images/productos/` y asegúrate de que el nombre del archivo en `productos.json` coincida exactamente con la ruta relativa.
*   **Datos de Contacto:** Los datos de contacto (dirección, teléfono, email) están codificados en los archivos HTML (`index.html`, `nosotros.html`, `contacto.html`). Deben ser actualizados manualmente en cada archivo.

## 9. Advertencias Técnicas y Notas Importantes

*   **Formulario de Contacto:** El formulario en `contacto.html` es una **simulación**. El script `js/main.js` solo muestra una alerta de éxito (`alert('¡Gracias por tu mensaje! Te contactaremos pronto.');`) y no envía datos a un servidor. Para que funcione en producción, se debe integrar un servicio de backend (ej. Formspree, Netlify Forms, o un script PHP/Node.js).
*   **Duplicación de Código JS:** La función `createProductCard(product)` está definida tanto en `js/main.js` como en `js/productos.js`. Aunque funciona, una buena práctica de desarrollo sería refactorizarla a un archivo de utilidades compartido para evitar redundancia.
*   **Leaflet.js:** La librería de mapas se carga desde una CDN. Si se requiere un entorno sin conexión, se deben descargar los archivos CSS y JS de Leaflet e incluirlos localmente.
*   **SEO:** Las meta etiquetas de descripción y título están configuradas en cada HTML, lo cual es fundamental para el SEO. Asegúrate de mantenerlas relevantes.
